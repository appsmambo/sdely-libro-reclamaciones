<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,600" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('css/estilos.css')); ?>" type="text/css">
    <title>Libro de reclamaciones (Ley 29571) - Sdely.com</title>
  </head>
  <body>
    <section class="container">
      <h1>
        Gracias por enviar sus datos!!!
      </h1>
      <p>
        Instrucciones:
      </p>
      <ol>
        <li>do algo...
        <li>do algo...
        <li>do algo...
        <li>do algo...
        <li>do algo...
      </ol>
    </section>
  </body>
</html>